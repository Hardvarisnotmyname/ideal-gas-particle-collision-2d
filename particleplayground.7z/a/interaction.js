// ---------- Mouse and Touch Interaction ----------
let mouseState = {
  isDown: false,
  x: 0,
  y: 0,
  forceStrength: 100 // Strength of the mouse force effect
};

// Make globally accessible
window.mouseState = mouseState;

function setupInteraction(canvas) {
  // Mouse event handlers
  canvas.addEventListener('mousedown', (e) => {
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    mouseState.isDown = true;
    mouseState.x = (e.clientX - rect.left) * dpr;
    mouseState.y = (e.clientY - rect.top) * dpr;
  });

  canvas.addEventListener('mousemove', (e) => {
    if (mouseState.isDown) {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      mouseState.x = (e.clientX - rect.left) * dpr;
      mouseState.y = (e.clientY - rect.top) * dpr;
    }
  });

  canvas.addEventListener('mouseup', () => {
    mouseState.isDown = false;
  });

  canvas.addEventListener('mouseleave', () => {
    mouseState.isDown = false;
  });

  // Touch event handlers for mobile support
  canvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const touch = e.touches[0];
    mouseState.isDown = true;
    mouseState.x = (touch.clientX - rect.left) * dpr;
    mouseState.y = (touch.clientY - rect.top) * dpr;
  }, { passive: false });

  canvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    if (mouseState.isDown && e.touches.length > 0) {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const touch = e.touches[0];
      mouseState.x = (touch.clientX - rect.left) * dpr;
      mouseState.y = (touch.clientY - rect.top) * dpr;
    }
  }, { passive: false });

  canvas.addEventListener('touchend', () => {
    mouseState.isDown = false;
  });
}

// Make setup function globally accessible
window.setupInteraction = setupInteraction;
