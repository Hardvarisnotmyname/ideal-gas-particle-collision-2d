



let isRunning = true;
let lastRAF = performance.now();
let fpsSmooth = 60;

// ---------- Optimized main loop with TRUE FPS uncapping ----------
let frameCount = 0;
let physicsLoopId = null; // To hold the reference to our setInterval
let adaptiveFpsIntervalId = null; // To hold the adaptive FPS adjuster

let physicsTicks = 0;
let physicsFps = 0;

// measure physics loop rate every second
setInterval(() => {
  physicsFps = physicsTicks;
  physicsTicks = 0;
  document.getElementById("physicsFps").textContent = physicsFps;
}, 1000);

// The NEW physics-only loop
function physicsLoop() {
  if (!isRunning) return;
  physicsTicks++;
  // Get bond checks from the physics module AFTER it updates
  PhysicsModule.update(config);
  window.stats.bondChecks = PhysicsModule.bondChecks;

  if (frameCount % 3 === 0) {
    const particles = PhysicsModule.particles;
    const count = PhysicsModule.particleCount;
    let leftSum = 0, leftCount = 0, rightSum = 0, rightCount = 0;
    let leftSumSpeed = 0, rightSumSpeed = 0;
    let leftMaxSpeed = 0, rightMaxSpeed = 0;
    let validParticleCount = 0;
    const cx = config.width * (config.wallPosition / 100);

    for (let i = 0; i < count; i++) {
      const idx = i * 8;
      // Check for valid particles
      if (!Number.isFinite(particles[idx])) continue;
      validParticleCount++;

      const sp2 = particles[idx + 2] * particles[idx + 2] + particles[idx + 3] * particles[idx + 3];
      const speed = Math.sqrt(sp2);

      if (particles[idx] < cx) {
        leftSum += sp2;
        leftSumSpeed += speed;
        if (speed > leftMaxSpeed) leftMaxSpeed = speed;
        leftCount++;
      } else {
        rightSum += sp2;
        rightSumSpeed += speed;
        if (speed > rightMaxSpeed) rightMaxSpeed = speed;
        rightCount++;
      }
    }

    window.stats.leftBoxTemp = leftCount ? Math.sqrt(leftSum / leftCount) : 0;
    window.stats.rightBoxTemp = rightCount ? Math.sqrt(rightSum / rightCount) : 0;
    window.stats.leftAvgSpeed = leftCount ? leftSumSpeed / leftCount : 0;
    window.stats.rightAvgSpeed = rightCount ? rightSumSpeed / rightCount : 0;
    window.stats.leftMaxSpeed = leftMaxSpeed;
    window.stats.rightMaxSpeed = rightMaxSpeed;
    window.stats.totalParticles = validParticleCount; // Update live count

    // Update bond statistics
    window.stats.totalBonds = BondSystem.bonds.length;
    window.stats.avgBondsPerParticle = validParticleCount > 0 ? (window.stats.totalBonds * 2) / validParticleCount : 0;

    window.pushHistory(window.stats.leftBoxTemp, window.stats.rightBoxTemp);
  }

  window.stats.collisionChecks = PhysicsModule.collisionStats ? PhysicsModule.collisionStats.checks : 0;
  window.stats.collisionRate = PhysicsModule.collisionStats ? PhysicsModule.collisionStats.collisions : 0;
}

// The MODIFIED main loop is now for rendering ONLY
function mainLoop(ts) {
  // We still request a new frame to keep the rendering loop going
  requestAnimationFrame(mainLoop);

  // But we respect the pause button for rendering
  if (!isRunning) {
    lastRAF = ts;
    return;
  }

  const dt = (ts - lastRAF) / 1000;
  lastRAF = ts;

  // Avoid massive dt values if the tab was inactive
  if (dt > 0.1) return;

  // Clamp dt to prevent division by very small numbers
  const minDt = 1 / 240; // Minimum dt for 240 FPS
  const clampedDt = Math.max(dt, minDt);
  const currentFps = 1 / clampedDt;
  fpsSmooth = fpsSmooth * 0.95 + currentFps * 0.05;
  window.stats.fps = fpsSmooth;

  // --- Physics update is REMOVED from here ---

// Render particles and bonds with WebGL
renderer.render(PhysicsModule.particles, PhysicsModule.particleCount, BondSystem.bonds);

// Draw walls on overlay with Canvas 2D
renderer.drawWalls();

  // Update UI less frequently
  if (frameCount % 5 === 0) {
    window.updateStatsDOM();
  }

  frameCount++;
}

// Create renderer
window.createRenderer = function(canvas, overlay, cfg) {
  const renderer = new Renderer(canvas, overlay, cfg);
  window.graphManager = new GraphManager();

  // Make renderer globally accessible
  window.renderer = renderer;

  function resize(){ if (renderer) renderer.resize(); }
  window.addEventListener('resize', () => { if (renderer) renderer.resize(); });
  resize();

  return renderer;
};

// Tab switching logic
document.querySelectorAll('.tab-button').forEach(button => {
  button.addEventListener('click', () => {
    const tab = button.getAttribute('data-tab');
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.remove('active');
    });
    document.getElementById(`${tab}`).classList.add('active');
    document.querySelectorAll('.tab-button').forEach(btn => {
      btn.classList.remove('active');
    });
    button.classList.add('active');
  });
});

// Create renderer after config is defined
let canvas = document.getElementById('canvas');
let overlay = document.getElementById('overlay');
createRenderer(canvas, overlay, config);

// Set up mouse event handlers now that canvas is available
window.setupInteraction(canvas);

// Wire UI
window.wireUI();

// Bind tooltips
window.bindTooltips();

// Initialize physics and start
document.getElementById('loading').textContent = 'Seeding particles...';
PhysicsModule.init(config.particleCount);

// Start the default capped physics loop (60Hz)
if (!physicsLoopId) {
    physicsLoopId = setInterval(physicsLoop, 1000 / 60);
}

document.getElementById('loading').style.display = 'none';

// Start the rendering loop
requestAnimationFrame(mainLoop);

// Dynamically set value box widths based on formatted display values
document.querySelectorAll(".control-group").forEach(group => {
  const slider = group.querySelector("input[type=range]");
  const valueBox = group.querySelector(".value");

  if (slider && valueBox) {
    // Get the current formatted value to determine the display format
    const currentValue = valueBox.textContent;
    const maxValue = slider.max;

    // Determine the formatted max value based on the current display format
    let formattedMax = maxValue;

    if (currentValue.includes('px')) {
      formattedMax = maxValue + 'px';
    } else if (currentValue.includes('%')) {
      formattedMax = maxValue + '%';
    } else if (currentValue.includes('.')) {
      // Count decimal places in current value
      const decimalPlaces = (currentValue.split('.')[1] || '').length;
      formattedMax = Number(maxValue).toFixed(decimalPlaces);
    } else if (currentValue === 'All') {
      // Special case for nodeBranches
      formattedMax = 'All';
    }

    const maxChars = String(formattedMax).length;
    valueBox.style.width = maxChars + "ch";
    valueBox.style.textAlign = "right";
    valueBox.style.fontVariantNumeric = "tabular-nums";
    valueBox.style.overflow = "hidden";
    valueBox.style.whiteSpace = "nowrap";
  }
});
