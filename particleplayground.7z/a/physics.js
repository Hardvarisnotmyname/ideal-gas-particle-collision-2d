// ---------- Optimized Physics Module ----------
let PhysicsModule = (function(){
  const Module = { ready:false, particles:null, particleCount:0, bondChecks: 0 };

  // Spatial grid for force calculations
  let spatialGrid = null;
  let gridWidth = 0;
  let gridHeight = 0;

  // Force sampling variables - persistent across calls for better distribution
  let forceUpdateOffset = 0;

  function reinitGrid(width, height, cellSize) {
    gridWidth = Math.ceil(width / cellSize);
    gridHeight = Math.ceil(height / cellSize);
    spatialGrid = new Array(gridWidth * gridHeight);
    for(let i = 0; i < spatialGrid.length; i++) {
      spatialGrid[i] = [];
    }
  }

  // Teleportation functions for Maxwell's Demon
  function teleportSlowParticle(p, n, cx, thresholdSq, direction) {
    const candidates = [];
    for(let i = 0; i < n; i++) {
      const idx = i * 8;
      const px = p[idx];
      const speedSq = p[idx+2]*p[idx+2] + p[idx+3]*p[idx+3];
      if(direction === 'rightToLeft' && px > cx && speedSq < thresholdSq) {
        candidates.push(idx);
      }
    }
    if(candidates.length > 0) {
      const chosenIdx = candidates[Math.floor(Math.random() * candidates.length)];
      p[chosenIdx] = Math.random() * (cx - 20) + 10;
      p[chosenIdx + 1] = Math.random() * (config.height - 20) + 10;
    }
  }

  function teleportFastParticle(p, n, cx, thresholdSq, direction) {
    const candidates = [];
    for(let i = 0; i < n; i++) {
      const idx = i * 8;
      const px = p[idx];
      const speedSq = p[idx+2]*p[idx+2] + p[idx+3]*p[idx+3];
      if(direction === 'leftToRight' && px < cx && speedSq >= thresholdSq) {
        candidates.push(idx);
      }
    }
    if(candidates.length > 0) {
      const chosenIdx = candidates[Math.floor(Math.random() * candidates.length)];
      p[chosenIdx] = Math.random() * (config.width - cx - 20) + cx + 10;
      p[chosenIdx + 1] = Math.random() * (config.height - 20) + 10;
    }
  }

  function clearSpatialGrid() {
    for(let i = 0; i < spatialGrid.length; i++) {
      spatialGrid[i].length = 0;
    }
  }

  function addToSpatialGrid(particleIndex, x, y, cellSize) {
    const gx = Math.floor(x / cellSize);
    const gy = Math.floor(y / cellSize);
    if(gx >= 0 && gx < gridWidth && gy >= 0 && gy < gridHeight) {
      spatialGrid[gy * gridWidth + gx].push(particleIndex);
    }
  }

  function updateParticleCount(newCount) {
    if (newCount === Module.particleCount) return;
    BondSystem.clear();
    const oldCount = Module.particleCount;
    const newParticles = new Float32Array(newCount * 8);
    const copyCount = Math.min(newCount, oldCount);

    if (oldCount > 0 && Module.particles) {
      for (let i = 0; i < copyCount * 8; i++) {
        newParticles[i] = Module.particles[i];
      }
    }

    if (newCount > oldCount) {
      const w = config.width, h = config.height, margin = config.radius + 1;
      const cx = w * (config.wallPosition / 100);
      for (let i = oldCount; i < newCount; i++) {
        const idx = i * 8;
        const isLeft = (i % 2 === 0);
        const bxMin = isLeft ? margin : cx + margin;
        const bxMax = isLeft ? cx - margin : w - margin;
        newParticles[idx] = Math.random() * (bxMax - bxMin) + bxMin;
        newParticles[idx + 1] = Math.random() * (h - 2 * margin) + margin;
        const speed = (isLeft ? config.leftTemp : config.rightTemp) * (Math.random() * 0.6 + 0.7) / 50;
        const ang = Math.random() * Math.PI * 2;
        newParticles[idx + 2] = Math.cos(ang) * speed;
        newParticles[idx + 3] = Math.sin(ang) * speed;
        newParticles[idx + 7] = config.radius;
      }
    }

    Module.particles = newParticles;
    Module.particleCount = newCount;
    BondSystem.init(newCount);
    updateColors();
  }

  function init(count){
    Module.particleCount = count;
    Module.particles = new Float32Array(count * 8);
    const w = config.width, h = config.height, margin = config.radius + 1;
    const cx = w * (config.wallPosition / 100);

    reinitGrid(w, h, config.gridSize);

    // Initialize bond system
    BondSystem.init(count);

    for(let i=0;i<count;i++){
      const idx=i*8;
      const left = (i%2===0);
      const bxMin = left? margin : cx+margin;
      const bxMax = left? cx-margin : w-margin;
      Module.particles[idx] = Math.random()*(bxMax-bxMin)+bxMin;
      Module.particles[idx+1] = Math.random()*(h-2*margin)+margin;
      const speed = (left?config.leftTemp:config.rightTemp) * (Math.random()*0.6+0.7)/50;
      const ang=Math.random()*Math.PI*2;
      Module.particles[idx+2]=Math.cos(ang)*speed;
      Module.particles[idx+3]=Math.sin(ang)*speed;
      Module.particles[idx+4]=0;
      Module.particles[idx+5]=0;
      Module.particles[idx+6]=0;
      Module.particles[idx+7]=config.radius;
    }
    updateColors();
    Module.ready=true;
    return Module;
  }

  function update(cfg){
    if(!Module.ready) return;
    const dt = 1/60/cfg.substeps;

    // Update bond system
    BondSystem.enabled = cfg.nodeMode;
    // This now handles its own update frequency
    BondSystem.update(Module.particles, Module.particleCount, cfg);
    Module.bondChecks = BondSystem.getBondChecks();

    for(let s=0;s<cfg.substeps;s++){
      applyForces(dt,cfg);
      // Apply bond forces after regular forces
      if (BondSystem.enabled) {
        BondSystem.applyBondForces(Module.particles, Module.particleCount, cfg, dt);
      }
      updatePositions(dt,cfg);
      handleCollisions(cfg);
    }
    updateColors();
  }

  function applyForces(dt, cfg) {
    const p = Module.particles;
    const n = Module.particleCount;
    const EPS = 1e-8;
    const cellSize = cfg.gridSize;

    // Apply mouse forces if mouse is down
    if (mouseState.isDown) {
      const mouseX = mouseState.x;
      const mouseY = mouseState.y;
      const forceStrength = mouseState.forceStrength;

      for (let i = 0; i < n; i++) {
        const idx = i * 8;
        const px = p[idx];
        const py = p[idx + 1];

        const dx = px - mouseX;
        const dy = py - mouseY;
        const dist2 = dx * dx + dy * dy;

        if (dist2 > 1 && dist2 < 10000) { // Effect radius ~100px
          const dist = Math.sqrt(dist2);
          const nx = dx / dist;
          const ny = dy / dist;

          // Divergence force (radial)
          let radialForce = 0;
          if (cfg.divergenceInward) {
            radialForce = -forceStrength / dist; // Inward (negative = towards mouse)
          } else {
            radialForce = forceStrength / dist; // Outward (positive = away from mouse)
          }

          // Curl force (tangential)
          let tangentX = -ny; // Perpendicular to radial
          let tangentY = nx;
          if (!cfg.curlClockwise) {
            tangentX = ny; // Reverse for anticlockwise
            tangentY = -nx;
          }
          const curlForce = forceStrength / dist;

          // Combine forces
          const fx = nx * radialForce + tangentX * curlForce * 0.5;
          const fy = ny * radialForce + tangentY * curlForce * 0.5;

          p[idx + 2] += fx * dt * 10; // Scale up for unreasonable effect
          p[idx + 3] += fy * dt * 10;
        }
      }
    }

    if (cfg.gravity || cfg.pressure) {
      clearSpatialGrid();
      for (let i = 0; i < n; i++) {
        const idx = i * 8;
        const x = p[idx], y = p[idx + 1];
        if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
        addToSpatialGrid(i, x, y, cellSize);
      }
    }
	
	
    let forceFraction = 1.0; // Default to 100%
    if (n > 10000) forceFraction = 0.02;//5% sampling default for many particles

    const forceParticleCount = Math.max(1, Math.floor(n * forceFraction));
    const forceStep = Math.max(1, Math.floor(n / forceParticleCount));
    const invFraction = 1 / forceFraction;
    const exponent = cfg.gravityExponent;
    const softening = 1;

    forceUpdateOffset = (forceUpdateOffset + 1) % forceStep;

    for (let i = 0; i < n; i++) {
      const idx = i * 8;
      let fx = 0, fy = 0;

      const vx0 = p[idx + 2], vy0 = p[idx + 3];
      const speed2 = vx0 * vx0 + vy0 * vy0;
      const maxSpeed2 = cfg.tunneling * cfg.tunneling;

      if (speed2 > maxSpeed2) {
        const scale = cfg.tunneling / Math.sqrt(speed2);
        p[idx + 2] *= scale;
        p[idx + 3] *= scale;
      }

      if (cfg.drag && speed2 > 1e-6) {
        const speed = Math.sqrt(speed2);
        const dragMag = cfg.dragCoeff * speed2;
        fx -= (p[idx + 2] / speed) * dragMag;
        fy -= (p[idx + 3] / speed) * dragMag;
      }

      // Apply downward gravity
      if (cfg.downwardGravity) {
        fy += 9.8; // Gravity constant (adjustable)
      }

      const shouldCalculateExpensiveForces = (cfg.gravity || cfg.pressure) &&
                                            ((i + forceUpdateOffset) % forceStep === 0);

      if (shouldCalculateExpensiveForces) {
        const x = p[idx], y = p[idx + 1];
        if (!Number.isFinite(x) || !Number.isFinite(y)) {
          p[idx + 2] = 0; p[idx + 3] = 0;
        } else {
          const gx = Math.floor(x / cellSize);
          const gy = Math.floor(y / cellSize);
          if (Number.isFinite(gx) && Number.isFinite(gy)) {
            // Use cfg.gravityDistance for gravity range
            const gravityRange = cfg.gravity ? cfg.gravityDistance : 0;
            const pressureRange = cfg.pressure ? 1 : 0;
            const maxRange = Math.max(gravityRange, pressureRange);
            let gravForce = 0;
            for (let dx = -maxRange; dx <= maxRange; dx++) {
              for (let dy = -maxRange; dy <= maxRange; dy++) {
                const cellX = gx + dx;
                const cellY = gy + dy;
                if (cellX < 0 || cellX >= gridWidth || cellY < 0 || cellY >= gridHeight) continue;
                const cell = spatialGrid[cellY * gridWidth + cellX];
                if (!cell) continue;
                const cellDist2 = dx * dx + dy * dy;

                for (let k = 0; k < cell.length; k++) {
                  const j = cell[k];
                  if (i === j) continue;
                  const jdx = j * 8;
                  const dxp = p[jdx] - x;
                  const dyp = p[jdx + 1] - y;
                  const dist2 = dxp * dxp + dyp * dyp;
                  const dist = Math.sqrt(dist2);
                  const dist3 = dist * dist2; // This is dist^3

                  if(dist2 < 1) continue;
                  const invDist = 1 / dist;
                  const nx = dxp * invDist;
                  const ny = dyp * invDist;

                  const softenedDist2 = dist2 + softening*softening;
                  const softenedDist = Math.sqrt(dist2 + softening * softening);
                  const softenedDist3 = softenedDist * softenedDist * softenedDist;
                  if (cfg.gravity && cellDist2 <= gravityRange * gravityRange) {
                    if (exponent == 2) {
                      gravForce = ((cfg.gravityStrength * invFraction) / softenedDist2) - (cfg.repulsionCoeff * cfg.repulsionCoeff * invFraction / softenedDist3);
                    } else {
                      const distPow = Math.pow(softenedDist2, exponent / 2);
                      gravForce = (cfg.gravityStrength * invFraction) / distPow;
                    }
                    fx += nx * gravForce;
                    fy += ny * gravForce;
                  }

                  if (cfg.pressure && cellDist2 <= pressureRange * pressureRange) {
                    const maxPressDist = p[idx + 7] * 8;
                    const dist = 1 / invDist;
                    if (dist < maxPressDist) {
                      const pressForce = (cfg.pressureStrength * invDist * invFraction * 0.6);
                      fx -= nx * pressForce;
                      fy -= ny * pressForce;
                    }
                  }
                }
              }
            }
          }
        }
      }
      if (!Number.isFinite(fx)) fx = 0;
      if (!Number.isFinite(fy)) fy = 0;
      p[idx + 2] += fx * dt;
      p[idx + 3] += fy * dt;
    }
  }

  function updateParticleTemperatures(leftTemp, rightTemp) {
    if (!Module.ready) return;
    const p = Module.particles;
    const n = Module.particleCount;
    const cx = config.width * (config.wallPosition / 100);

    for (let i = 0; i < n; i++) {
      const idx = i * 8;
      const x = p[idx];
      const isLeft = x < cx;
      const currentSpeed = Math.sqrt(p[idx + 2] * p[idx + 2] + p[idx + 3] * p[idx + 3]);
      const targetTemp = isLeft ? leftTemp : rightTemp;
      const targetSpeed = targetTemp * (Math.random() * 0.6 + 0.7) / 50;

      if (currentSpeed > 0.1) {
        const speedRatio = targetSpeed / currentSpeed;
        const adjustmentFactor = 0.2;
        const newSpeedRatio = 1 + (speedRatio - 1) * adjustmentFactor;
        p[idx + 2] *= newSpeedRatio;
        p[idx + 3] *= newSpeedRatio;
      } else {
        const ang = Math.random() * Math.PI * 2;
        p[idx + 2] = Math.cos(ang) * targetSpeed;
        p[idx + 3] = Math.sin(ang) * targetSpeed;
      }
    }
  }

  // New: update only left or only right side temperatures (for independent sliders)
  function updateLeftParticleTemperatures(leftTemp) {
    if (!Module.ready) return;
    const p = Module.particles; const n = Module.particleCount;
    const cx = config.width * (config.wallPosition / 100);
    for (let i = 0; i < n; i++) {
      const idx = i * 8;
      const x = p[idx];
      if (x < cx) {
        const currentSpeed = Math.sqrt(p[idx + 2] * p[idx + 2] + p[idx + 3] * p[idx + 3]);
        const targetSpeed = leftTemp * 0.65 / 50;
        if (currentSpeed > 0.1) {
          const speedRatio = targetSpeed / currentSpeed;
          const newSpeedRatio = 1 + (speedRatio - 1) * 0.2;
          p[idx + 2] *= newSpeedRatio; p[idx + 3] *= newSpeedRatio;
        } else {
          const ang = Math.random() * Math.PI * 2;
          p[idx + 2] = Math.cos(ang) * targetSpeed;
          p[idx + 3] = Math.sin(ang) * targetSpeed;
        }
      }
    }
  }
  function updateRightParticleTemperatures(rightTemp) {
    if (!Module.ready) return;
    const p = Module.particles; const n = Module.particleCount;
    const cx = config.width * (config.wallPosition / 100);
    for (let i = 0; i < n; i++) {
      const idx = i * 8;
      const x = p[idx];
      if (x >= cx) {
        const currentSpeed = Math.sqrt(p[idx + 2] * p[idx + 2] + p[idx + 3] * p[idx + 3]);
        const targetSpeed = rightTemp * 0.65 / 50;
        if (currentSpeed > 0.1) {
          const speedRatio = targetSpeed / currentSpeed;
          const newSpeedRatio = 1 + (speedRatio - 1) * 0.2;
          p[idx + 2] *= newSpeedRatio; p[idx + 3] *= newSpeedRatio;
        } else {
          const ang = Math.random() * Math.PI * 2;
          p[idx + 2] = Math.cos(ang) * targetSpeed;
          p[idx + 3] = Math.sin(ang) * targetSpeed;
        }
      }
    }
  }

  function updatePositions(dt, cfg) {
    const p = Module.particles;
    const n = Module.particleCount;
    const w = cfg.width, h = cfg.height;
    const cx = w * (cfg.wallPosition / 100);
    const pipeTop = h / 2 - (cfg.pipeHeight / 100) * h / 2;
    const pipeBottom = h / 2 + (cfg.pipeHeight / 100) * h / 2;
    const wallT = 10;
    const demonThresholdSq = cfg.demonSpeedThreshold * cfg.demonSpeedThreshold;
    const EPS = 1e-6; // Small epsilon to avoid exact equality issues

    for (let i = 0; i < n; i++) {
        const idx = i * 8;
        let x = p[idx], y = p[idx + 1];
        let vx = p[idx + 2], vy = p[idx + 3];
        const r = p[idx + 7]/2;
        x += vx * dt;
        y += vy * dt;
        const restitution = 1;
        if (x - r < EPS) { x = r; vx = Math.abs(vx) * restitution; }
        if (x + r > w - EPS) { x = w - r; vx = -Math.abs(vx) * restitution; }
        if (y - r < EPS) { y = r; vy = Math.abs(vy) * restitution; }
        if (y + r > h - EPS) { y = h - r; vy = -Math.abs(vy) * restitution; }

        const leftWallEdge = cx - wallT/2;
        const rightWallEdge = cx + wallT/2;
        const isCrossingWall = (x > leftWallEdge && x < rightWallEdge) ||
                              (x + r > leftWallEdge && x < leftWallEdge) ||
                              (x - r < rightWallEdge && x > rightWallEdge);

        if (isCrossingWall) {
            const withinPipe = cfg.pipeOpen && (y >= pipeTop && y <= pipeBottom);
            let shouldBounce = false;
            if (cfg.maxwellDemon) {
                const speedSq = vx*vx + vy*vy;
                const isMovingRight = vx > 0;
                const isFastParticle = speedSq >= demonThresholdSq;
                if (isMovingRight && isFastParticle) {
                    teleportSlowParticle(p, n, cx, demonThresholdSq, 'rightToLeft');
                } else if (!isMovingRight && !isFastParticle) {
                    teleportFastParticle(p, n, cx, demonThresholdSq, 'leftToRight');
                } else {
                    shouldBounce = true;
                }
            } else if (!withinPipe) {
                shouldBounce = true;
            }
            if (shouldBounce) {
                if (x > leftWallEdge && x < rightWallEdge) {
                    const distToLeft = x - leftWallEdge;
                    const distToRight = rightWallEdge - x;
                    if (distToLeft < distToRight) {
                        x = leftWallEdge - r;
                        vx = -Math.abs(vx) * restitution;
                    } else {
                        x = rightWallEdge + r;
                        vx = Math.abs(vx) * restitution;
                    }
                } else if (x + r > leftWallEdge && x < leftWallEdge) {
                    x = leftWallEdge - r;
                    vx = -Math.abs(vx) * restitution;
                } else if (x - r < rightWallEdge && x > rightWallEdge) {
                    x = rightWallEdge + r;
                    vx = Math.abs(vx) * restitution;
                }
            }
        }
        p[idx] = x; p[idx + 1] = y;
        p[idx + 2] = vx; p[idx + 3] = vy;
    }
  }

  // HandleCollisions remains the same... (pasting for completeness of the block)
  const CollisionStats = { collisions:0, checks:0 };
  function handleCollisions(cfg){
    const p = Module.particles;
    const n = Module.particleCount;
    CollisionStats.collisions = 0;
    CollisionStats.checks = 0;

    if(cfg.useSAP){
      const idxs = new Uint32Array(n);
      for(let i=0;i<n;i++) idxs[i]=i;
      const positions = new Float32Array(n);
      for(let i=0;i<n;i++) positions[i] = p[i*8];
      idxs.sort((a,b) => positions[a] - positions[b]);

      for(let i=0;i<n;i++){
        const a = idxs[i]*8;
        const ax = p[a], ay = p[a+1], ar = p[a+7];
        let collisionCount = 0;
        const maxCollisionsPerParticle = 8;

        for(let j=i+1;j<n && collisionCount < maxCollisionsPerParticle;j++){
          const b = idxs[j]*8;
          const bx = p[b];
          if(bx - p[b+7] > ax + ar) break;
          CollisionStats.checks++;
          const dx = bx - ax;
          const dy = p[b+1] - ay;
          const dist2 = dx*dx + dy*dy;
          const minD = (ar + p[b+7])/2;
          const minD2 = minD * minD;

          if(dist2 < minD2 && dist2 > 0.01){
            CollisionStats.collisions++;
            collisionCount++;
            const dist = Math.sqrt(dist2);
            const nx = dx / dist;
            const ny = dy / dist;
            const v1x = p[a+2], v1y = p[a+3];
            const v2x = p[b+2], v2y = p[b+3];
            const kx = v1x - v2x;
            const ky = v1y - v2y;
            const momentum = (nx * kx + ny * ky);
            if(cfg.friction) {
              const f = cfg.frictionCoeff;
              p[a+2] = (v1x - momentum * nx) * f;
              p[a+3] = (v1y - momentum * ny) * f;
              p[b+2] = (v2x + momentum * nx) * f;
              p[b+3] = (v2y + momentum * ny) * f;
            } else {
              p[a+2] = v1x - momentum * nx;
              p[a+3] = v1y - momentum * ny;
              p[b+2] = v2x + momentum * nx;
              p[b+3] = v2y + momentum * ny;
            }
            const overlap = minD - dist;
            const sep = Math.min(overlap * 0.6, minD * 0.2);
            p[a] -= nx * sep;
            p[a+1] -= ny * sep;
            p[b] += nx * sep;
            p[b+1] += ny * sep;
          }
        }
      }
    } else {
      const cell = Math.max(8, cfg.radius*3);
      const gw = Math.ceil(cfg.width/cell);
      const gh = Math.ceil(cfg.height/cell);
      const grid = new Array(gw*gh);
      for(let i=0;i<grid.length;i++) grid[i] = [];
      for(let i=0;i<n;i++){
        const idx=i*8;
        const gx=Math.floor(p[idx]/cell);
        const gy=Math.floor(p[idx+1]/cell);
        if(gx>=0&&gx<gw&&gy>=0&&gy<gh) grid[gy*gw+gx].push(i);
      }
      for(let g=0;g<grid.length;g++){
        const cellArr=grid[g];
        const cellSize = cellArr.length;
        if(cellSize > 250) continue;
        for(let a=0;a<cellSize;a++){
          for(let b=a+1;b<cellSize;b++){
            const ai=cellArr[a]*8, bi=cellArr[b]*8;
            CollisionStats.checks++;
            const dx=p[bi]-p[ai];
            const dy=p[bi+1]-p[ai+1];
            const dist2=dx*dx+dy*dy;
            const minD=(p[ai+7]+p[bi+7])/2;
            const minD2 = minD*minD;
            if(dist2<minD2 && dist2>0.01){
              CollisionStats.collisions++;
              const dist = Math.sqrt(dist2);
              const nx = dx / dist;
              const ny = dy / dist;
              const v1x = p[ai+2], v1y = p[ai+3];
              const v2x = p[bi+2], v2y = p[bi+3];
              const kx = v1x - v2x;
              const ky = v1y - v2y;
              const momentum = (nx * kx + ny * ky);
              if(cfg.friction) {
                const f = cfg.frictionCoeff;
                p[ai+2] = (v1x - momentum * nx) * f;
                p[ai+3] = (v1y - momentum * ny) * f;
                p[bi+2] = (v2x + momentum * nx) * f;
                p[bi+3] = (v2y + momentum * ny) * f;
              } else {
                p[ai+2] = v1x - momentum * nx;
                p[ai+3] = v1y - momentum * ny;
                p[bi+2] = v2x + momentum * nx;
                p[bi+3] = v2y + momentum * ny;
              }
              const overlap = minD - dist;
              const sep = Math.min(overlap * 0.6, minD * 0.2);
              p[ai] -= nx * sep;
              p[ai+1] -= ny * sep;
              p[bi] += nx * sep;
              p[bi+1] += ny * sep;
            }
          }
        }
      }
    }
    Module.collisionStats = { collisions: CollisionStats.collisions, checks: CollisionStats.checks };
  }

  let lastColorUpdate = 0;
  function updateColors(){
    const now = performance.now();
    if(now - lastColorUpdate < 33) return; // optimize: update colors ~30fps to reduce overhead
    lastColorUpdate = now;
    const p=Module.particles, n=Module.particleCount;
    for(let i=0;i<n;i++){
      const idx=i*8;
      const speed2 = p[idx+2]*p[idx+2] + p[idx+3]*p[idx+3];
      const speed = Math.sqrt(speed2);
      const hue = 240-Math.min(speed*6,240);
      const rgb=hslToRgb(hue/360,1,0.5);
      p[idx+4]=rgb[0];
      p[idx+5]=rgb[1];
      p[idx+6]=rgb[2];
    }
  }

  return {
    init,
    update,
    updateParticleTemperatures,
    updateLeftParticleTemperatures,
    updateRightParticleTemperatures,
    updateParticleCount,
    reinitGrid: ()=>reinitGrid(config.width, config.height, config.gridSize), // Expose grid re-init
    get particles(){return Module.particles;},
    get particleCount(){return Module.particleCount;},
    get collisionStats(){return Module.collisionStats||{collisions:0,checks:0}},
    ready:()=>Module.ready,
    get bondChecks(){return Module.bondChecks||0}
  };
})();
