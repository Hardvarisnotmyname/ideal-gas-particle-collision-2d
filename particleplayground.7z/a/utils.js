// ---------- Utilities ----------
// js to make css tooltip not going offscreen stuff
(function(){
  // Single, reusable tooltip element
  const tip = document.createElement('div');
  tip.className = 'ui-tooltip';
  document.body.appendChild(tip);

  let currentTarget = null;
  const GAP = 8; // px gap from target

  function placeTooltip(target){
    const rect = target.getBoundingClientRect();

    // Preferred position: below center of target
    let x = rect.left + rect.width/2;
    let y = rect.bottom + GAP;

    // Set content first so we can measure size
    // (content already set in showTooltip)
    tip.style.transform = 'translate(0px,0px)';
    const w = tip.offsetWidth;
    const h = tip.offsetHeight;

    // Clamp horizontally to viewport
    let left = x - w/2;
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));

    // If doesn't fit below, place above
    let top = y;
    if (top + h + 8 > window.innerHeight) {
      top = rect.top - h - GAP;
    }

    tip.style.transform = `translate(${left}px, ${Math.max(8, top)}px)`;
  }

  function showTooltip(target){
    const txt = target.getAttribute('data-tooltip');
    if (!txt) return;
    currentTarget = target;
    tip.textContent = txt;
    tip.setAttribute('data-visible','true');
    placeTooltip(target);
  }

  function hideTooltip(){
    currentTarget = null;
    tip.removeAttribute('data-visible');
    // park it offscreen
    tip.style.transform = 'translate(-9999px,-9999px)';
  }

  // Event bindings for any element with data-tooltip
  function bind(el){
    el.addEventListener('mouseenter', ()=> showTooltip(el));
    el.addEventListener('mouseleave', hideTooltip);
    el.addEventListener('mousemove', ()=> placeTooltip(el));
    el.addEventListener('focus', ()=> showTooltip(el));
    el.addEventListener('blur', hideTooltip);
    el.addEventListener('touchstart', ()=> showTooltip(el), {passive:true});
    el.addEventListener('touchend', hideTooltip, {passive:true});
  }

  // 👇 Expose one global function
  window.bindTooltips = function(){
    document.querySelectorAll('[data-tooltip]').forEach(bind);
  };
})();

function clamp(v,a,b){return Math.max(a,Math.min(b,v));}

function hslToRgb(h,s,l){ // h in [0,1]
  let r,g,b;
  if(s==0) r=g=b=l; else{
    const q = l<0.5?l*(1+s):l+s-l*s; const p = 2*l-q;
    const hue2rgb=(p,q,t)=>{ if(t<0) t+=1; if(t>1) t-=1; if(t<1/6) return p+(q-p)*6*t; if(t<1/2) return q; if(t<2/3) return p+(q-p)*(2/3-t)*6; return p };
    r=hue2rgb(p,q,h+1/3); g=hue2rgb(p,q,h); b=hue2rgb(p,q,h-1/3);
  }
  return [r,g,b];
}
