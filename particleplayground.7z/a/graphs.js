// ---------- Graphs and Stats ----------
// Graph/History
const maxFullHistory = 2000;
const recentPoints = 120;
let leftFull = [];
let rightFull = [];
let leftRecent = [];
let rightRecent = [];

// Stats
const stats = { fps:0, collisionRate:0, collisionChecks:0, leftBoxTemp:0, rightBoxTemp:0, totalParticles:0, leftAvgSpeed:0, rightAvgSpeed:0, leftMaxSpeed:0, rightMaxSpeed:0, totalBonds:0, avgBondsPerParticle:0 };
stats.bondChecks = 0;

// FPS targeting variables
let targetFps = 60;

// ---------- Graph reset function ----------
function resetGraphs() {
  if (graphManager) graphManager.reset();
}

class GraphManager {
  constructor() {
    this.leftFull = []; this.rightFull = [];
    this.leftRecent = []; this.rightRecent = [];
  }
  reset() {
    this.leftFull = []; this.rightFull = [];
    this.leftRecent = []; this.rightRecent = [];
    const ids = ['leftTempRecentGraph','rightTempRecentGraph','leftTempFullGraph','rightTempFullGraph'];
    ids.forEach(id => { const c = document.getElementById(id); if (c) c.getContext('2d').clearRect(0,0,c.width,c.height); });
  }
  pushHistory(l, r) {
    this.leftRecent.push(l); this.rightRecent.push(r);
    this.leftFull.push(l); this.rightFull.push(r);
    if (this.leftRecent.length > recentPoints) this.leftRecent.shift();
    if (this.rightRecent.length > recentPoints) this.rightRecent.shift();
    if (this.leftFull.length > maxFullHistory) this.leftFull.shift();
    if (this.rightFull.length > maxFullHistory) this.rightFull.shift();
  }
  drawAll() {
    drawMiniGraph(document.getElementById('leftTempRecentGraph'), this.leftRecent, true);
    drawMiniGraph(document.getElementById('rightTempRecentGraph'), this.rightRecent, true);
    drawMiniGraph(document.getElementById('leftTempFullGraph'), this.leftFull, false);
    drawMiniGraph(document.getElementById('rightTempFullGraph'), this.rightFull, false);
  }
}

// ---------- UI helpers & graphs ----------
function pushHistory(l, r){
  if (graphManager) graphManager.pushHistory(l, r);
}

function drawMiniGraph(canvasEl, data, autoScale=true){
  const ctx = canvasEl.getContext('2d');
  const W=canvasEl.width, H=canvasEl.height;
  ctx.clearRect(0,0,W,H);
  if(data.length<2) return;
  let min=Math.min(...data), max=Math.max(...data);
  if(!autoScale){ min=0; }
  const pad=6;
  const plotH=H-2*pad;
  const plotW=W-2*pad;
  const range = (max-min)||1;
  ctx.beginPath();
  for(let i=0;i<data.length;i++){
    const x = pad + (i/(data.length-1))*plotW;
    const y = pad + (1 - (data[i]-min)/range)*plotH;
    if(i===0) ctx.moveTo(x,y);
    else ctx.lineTo(x,y);
  }
  ctx.strokeStyle='rgba(0,255,136,0.9)';
  ctx.lineWidth=1.5;
  ctx.stroke();
}

function colorStat(leftId, rightId, leftVal, rightVal) {
  const leftEl = document.getElementById(leftId);
  const rightEl = document.getElementById(rightId);

  if (leftVal > rightVal) {
    leftEl.style.color = "limegreen";
    rightEl.style.color = "red";
  } else if (rightVal > leftVal) {
    rightEl.style.color = "limegreen";
    leftEl.style.color = "red";
  } else {
    leftEl.style.color = "#ccc";
    rightEl.style.color = "#ccc";
  }
}

function updateStatsDOM(){
  document.getElementById('fps').textContent = Math.round(stats.fps);
  document.getElementById('targetFps').textContent = config.uncapFps ? Math.round(targetFps) : '60';
  document.getElementById('collisionRate').textContent=Math.round(stats.collisionRate);
  document.getElementById('collisionChecks').textContent=Math.round(stats.collisionChecks);
  document.getElementById('totalParticles').textContent=stats.totalParticles; // Now live
  document.getElementById('bondChecks').textContent = stats.bondChecks || 0; // Show bond checks instead of render mode
  document.getElementById('leftBoxTemp').textContent=(stats.leftBoxTemp || 0).toFixed(2);
  document.getElementById('rightBoxTemp').textContent=(stats.rightBoxTemp || 0).toFixed(2);
  // NEW STATS
  document.getElementById('leftAvgSpeed').textContent=(stats.leftAvgSpeed || 0).toFixed(2);
  document.getElementById('rightAvgSpeed').textContent=(stats.rightAvgSpeed || 0).toFixed(2);
  document.getElementById('leftMaxSpeed').textContent=(stats.leftMaxSpeed || 0).toFixed(2);
  document.getElementById('rightMaxSpeed').textContent=(stats.rightMaxSpeed || 0).toFixed(2);
  // Bond stats
  document.getElementById('totalBonds').textContent = stats.totalBonds;
  document.getElementById('avgBondsPerParticle').textContent = (stats.avgBondsPerParticle || 0).toFixed(2);
    // Compare all left/right stat pairs
  colorStat("leftBoxTemp",   "rightBoxTemp",   stats.leftBoxTemp,   stats.rightBoxTemp);
  colorStat("leftAvgSpeed",  "rightAvgSpeed",  stats.leftAvgSpeed,  stats.rightAvgSpeed);
  colorStat("leftMaxSpeed",  "rightMaxSpeed",  stats.leftMaxSpeed,  stats.rightMaxSpeed);

  if (graphManager) graphManager.drawAll();
}

// Make globally accessible
window.graphManager = null;
window.stats = stats;
window.targetFps = targetFps;
window.pushHistory = pushHistory;
window.updateStatsDOM = updateStatsDOM;
window.resetGraphs = resetGraphs;
