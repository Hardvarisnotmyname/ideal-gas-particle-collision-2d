// ---------- Bond System ----------
const BondSystem = {
  bonds: [],
  particleBonds: [],
  enabled: false,
  updateCounter: 0,
  updateFrequency: 1, // Increase from 10 to 30 - less frequent full updates
  bondChecksThisFrame: 0,

  // Add these new properties for smoother updates
  maxChecksPerFrame: 10000, // Limit checks per frame
  lastCheckedParticle: 0,   // Track where we left off
  lastCheckedParticleJ: 0,  // Track where we left off for particleJ
  lastValidatedIndex: 0,    // Track validation rotation

  init(particleCount) {
    this.bonds = [];
    this.particleBonds = [];
    for (let i = 0; i < particleCount; i++) {
      this.particleBonds.push(new Set());
    }
  },

  clear() {
    this.bonds = [];
    for (let bonds of this.particleBonds) {
      bonds.clear();
    }
  },

  addBond(i, j, distance) {
    if (i === j) return false;
    if (this.particleBonds[i].has(j)) return false; // Already bonded

    const maxBranches = config.nodeBranches === -1 ? Infinity : config.nodeBranches;
    if (this.particleBonds[i].size >= maxBranches || this.particleBonds[j].size >= maxBranches) {
      return false; // Capacity exceeded
    }

    this.bonds.push({i, j, length: distance});
    this.particleBonds[i].add(j);
    this.particleBonds[j].add(i);
    return true;
  },

  removeBond(bondIndex) {
    if (bondIndex < 0 || bondIndex >= this.bonds.length) return;

    const bond = this.bonds[bondIndex];
    this.particleBonds[bond.i].delete(bond.j);
    this.particleBonds[bond.j].delete(bond.i);
    this.bonds.splice(bondIndex, 1);
  },

  update(particles, particleCount, cfg) {
    if (!this.enabled) {
      this.bondChecksThisFrame = 0;
      return;
    }

    this.updateCounter++;
    if (this.updateCounter >= this.updateFrequency) {
      this.updateCounter = 0;
      this.performIncrementalBondUpdate(particles, particleCount, cfg); // NEW: incremental
    } else {
      this.validateExistingBonds(particles, particleCount, cfg);
    }
  },

  getBondChecks() {
    return this.bondChecksThisFrame;
  },

  // NEW: Spread bond formation across multiple frames
  performIncrementalBondUpdate(particles, particleCount, cfg) {
    this.bondChecksThisFrame = 0;

    const minDist = cfg.nodeMinDist;
    const maxDist = cfg.nodeMaxDist === 1000 ? 10000 : cfg.nodeMaxDist;
    const maxBranches = cfg.nodeBranches === -1 ? Infinity : cfg.nodeBranches;

    // Prune excess bonds first (moved before early returns so it runs even when branches = 0)
    if (maxBranches !== Infinity) {
      for (let i = 0; i < particleCount; i++) {
        while (this.particleBonds[i].size > maxBranches) {
          for (let j = this.bonds.length - 1; j >= 0; j--) {
            const bond = this.bonds[j];
            if (bond.i === i || bond.j === i) {
              this.removeBond(j);
              break;
            }
          }
        }
      }
    }

    // Early returns for invalid settings
    if (cfg.nodeBranches === 0) return;
    if (cfg.nodeMinDist > cfg.nodeMaxDist) return;

    // Validate existing bonds
    this.validateExistingBonds(particles, particleCount, cfg);

    // PRIORITIZE: Check particles with fewer bonds first for better connectivity
    const particlesToCheck = Math.min(
      Math.ceil(particleCount * 0.2), // Check 20% of particles per frame
      this.maxChecksPerFrame / 10     // Limit based on max checks
    );

    // Create priority queue: particles with fewer bonds get checked first
    const priorityParticles = [];
    for (let i = 0; i < particleCount; i++) {
      const bondCount = this.particleBonds[i].size;
      if (bondCount < maxBranches) {
        priorityParticles.push({ index: i, bonds: bondCount });
      }
    }

    // Sort by bond count (ascending) - particles with fewer bonds first
    priorityParticles.sort((a, b) => a.bonds - b.bonds);

    // Select particles to check this frame, prioritizing those with fewer bonds
    const selectedParticles = [];
    let checked = 0;
    for (let i = 0; i < priorityParticles.length && checked < particlesToCheck; i++) {
      const particle = priorityParticles[(this.lastCheckedParticle + i) % priorityParticles.length];
      selectedParticles.push(particle.index);
      checked++;
    }

    // Update our position for next frame
    if (priorityParticles.length > 0) {
      this.lastCheckedParticle = (this.lastCheckedParticle + checked) % priorityParticles.length;
    } else {
      this.lastCheckedParticle = 0;
    }

    // Now check the selected particles
    for (let i = 0; i < selectedParticles.length && this.bondChecksThisFrame < this.maxChecksPerFrame; i++) {
      const particleI = selectedParticles[i];
      const iIdx = particleI * 8;

      if (this.particleBonds[particleI].size >= maxBranches) continue;

      const x = particles[iIdx];
      const y = particles[iIdx + 1];

      // Check more particles per particle for better connectivity
      const maxParticlesToCheck = Math.min(100, particleCount);

      let bondsAddedThisParticle = 0;
      const maxBondsPerParticle = Math.min(3, maxBranches - this.particleBonds[particleI].size);

      for (let j = 0; j < maxParticlesToCheck && bondsAddedThisParticle < maxBondsPerParticle && this.bondChecksThisFrame < this.maxChecksPerFrame; j++) {
        const particleJ = (this.lastCheckedParticleJ + j) % particleCount;

        if (particleI === particleJ) continue;
        if (this.particleBonds[particleI].has(particleJ)) continue;
        if (this.particleBonds[particleJ].size >= maxBranches) continue;

        const jIdx = particleJ * 8;
        const dx = particles[jIdx] - x;
        const dy = particles[jIdx + 1] - y;

        // Quick distance check before expensive sqrt
        const dist2 = dx * dx + dy * dy;
        if (dist2 < minDist * minDist || dist2 > maxDist * maxDist) {
          continue; // Skip this particle, don't count as checked
        }

        const dist = Math.sqrt(dist2);
        this.bondChecksThisFrame++;

        if (dist >= minDist && dist <= maxDist) {
          if (this.addBond(particleI, particleJ, dist)) {
            bondsAddedThisParticle++;
            // Don't break - allow multiple bonds per particle per frame
          }
        }
      }

      // Update particleJ position for next particleI
      this.lastCheckedParticleJ = (this.lastCheckedParticleJ + maxParticlesToCheck) % particleCount;
    }
  },

  // Optimized validation with rotating checks to ensure all bonds are eventually validated
  validateExistingBonds(particles, particleCount, cfg) {
    if (cfg.nodeMinDist > cfg.nodeMaxDist) return;
    const minDist = cfg.nodeMinDist;
    const maxDist = cfg.nodeMaxDist === 1000 ? 10000 : cfg.nodeMaxDist;
    const minDist2 = minDist * minDist;
    const maxDist2 = maxDist * maxDist;

    // Use rotating validation to ensure all bonds are checked over time
    // Check up to 5000 bonds per frame, but rotate through all bonds
    const bondsToCheck = Math.min(this.bonds.length, 5000);
    let startIndex = this.lastValidatedIndex || 0;

    for (let i = 0; i < bondsToCheck; i++) {
      const bondIndex = (startIndex + i) % this.bonds.length;
      const bond = this.bonds[bondIndex];

      if (!bond) continue; // Bond might have been removed

      const iIdx = bond.i * 8;
      const jIdx = bond.j * 8;
      const dx = particles[jIdx] - particles[iIdx];
      const dy = particles[jIdx + 1] - particles[iIdx + 1];
      const dist2 = dx * dx + dy * dy;

      this.bondChecksThisFrame++;

      if (dist2 < minDist2 || dist2 > maxDist2) {
        this.removeBond(bondIndex);
        // Adjust index since we removed a bond
        if (bondIndex < startIndex) {
          startIndex--;
        }
        i--; // Check one more bond since we removed one
      }
    }

    // Update the starting index for next frame
    this.lastValidatedIndex = (startIndex + bondsToCheck) % this.bonds.length;
  },

  applyBondForces(particles, particleCount, cfg, dt) {
    if (!this.enabled || !cfg.bondDynamics) return;

    const k = cfg.bondStiffness;
    const damping = cfg.bondDamping;
    const equilibriumLength = (cfg.nodeMaxDist + cfg.nodeMinDist) / 2;

    for (const bond of this.bonds) {
      const iIdx = bond.i * 8;
      const jIdx = bond.j * 8;

      const dx = particles[jIdx] - particles[iIdx];
      const dy = particles[jIdx + 1] - particles[iIdx + 1];
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist === 0) continue;

      // Hooke's law force
      const force = -k * (dist - equilibriumLength);

      // Normalize direction
      const nx = dx / dist;
      const ny = dy / dist;

      // Add damping
      const dvx = particles[jIdx + 2] - particles[iIdx + 2];
      const dvy = particles[jIdx + 3] - particles[iIdx + 3];
      const relativeVelocity = dvx * nx + dvy * ny;
      const dampingForce = -damping * relativeVelocity;

      const totalForce = force + dampingForce;
      const fx = totalForce * nx;
      const fy = totalForce * ny;

      // Apply forces (assuming unit mass)
      particles[iIdx + 2] -= fx * dt;
      particles[iIdx + 3] -= fy * dt;
      particles[jIdx + 2] += fx * dt;
      particles[jIdx + 3] += fy * dt;
    }
  },

  render(ctx, particles, particleCount) {
    if (!this.enabled || this.bonds.length === 0 || !config.bondLinesVisible) return;

    ctx.save();
    ctx.strokeStyle = `rgba(100, 200, 255, ${config.bondAlpha})`;
    ctx.lineWidth = config.bondThickness;
    ctx.globalCompositeOperation = 'screen';

    ctx.beginPath();
    for (const bond of this.bonds) {
      const iIdx = bond.i * 8;
      const jIdx = bond.j * 8;

      ctx.moveTo(particles[iIdx], particles[iIdx + 1]);
      ctx.lineTo(particles[jIdx], particles[jIdx + 1]);
    }
    ctx.stroke();
    ctx.restore();
  }
};
