// ---------- UI wiring ----------
function wireUI(){
  const set=(id,cb,fmt)=>{
    const el=document.getElementById(id);
    const lab=document.getElementById(id+'Value');
    const upd=()=>lab.textContent=fmt?fmt(el.value):el.value;
    el.addEventListener('input',()=>{ cb(el.value); upd(); });
    upd();
  };

  const updateParticleSliderMax = () => {
  const slider = document.getElementById('particleCount');
  const valueDisplay = document.getElementById('particleCountValue');

  if (config.nodeMode) {
    slider.max = 5000;
    // If current count exceeds 5000, reduce it immediately
    if (config.particleCount > 5000) {
      config.particleCount = 5000;
      slider.value = 5000;
      valueDisplay.textContent = 5000;
      // Actually update the physics module with the new count
      PhysicsModule.updateParticleCount(config.particleCount);
    }
  } else {
    slider.max = 10000;
  }
  // Update display to reflect current value after max change
  valueDisplay.textContent = slider.value;
};

  set('particleCount', v=>{
    config.particleCount=Number(v);
    if(PhysicsModule.ready()) {
      PhysicsModule.updateParticleCount(config.particleCount);
    }
  }, v=>v);

  set('leftTemp', v=> {
    config.leftTemp=Number(v);
    // Poll the temperature update 20 times to ensure particles reach target speed
    for(let i = 0; i < 20; i++) {
      PhysicsModule.updateLeftParticleTemperatures(config.leftTemp);
    }
  }, v=>v);
  set('rightTemp', v=> {
    config.rightTemp=Number(v);
    // Poll the temperature update 20 times to ensure particles reach target speed
    for(let i = 0; i < 20; i++) {
      PhysicsModule.updateRightParticleTemperatures(config.rightTemp);
    }
  }, v=>v);

  set('radius', v=> {
    config.radius=Number(v);
    if(PhysicsModule.particles) {
      const newRadius = config.radius;
      for(let i=0;i<PhysicsModule.particleCount;i++) {
        PhysicsModule.particles[i*8+7]=newRadius;
      }
    }
  }, v=>v+'px');
  set('pipeHeight', v=> config.pipeHeight=Number(v), v=>v+'%');
  set('substeps', v=> config.substeps=Math.max(1,Number(v)), v=>v);
  set('demonThreshold', v=> config.demonSpeedThreshold=Number(v), v=>v);
  set('pressureStrength', v=> config.pressureStrength=Number(v), v=>v);
  set('dragCoeff', v=> config.dragCoeff=Number(v), v=>Number(v).toFixed(4));

  // Gravity controls
  set('gravityStrength', v=> config.gravityStrength=Number(v), v=>v);
  set('gravityExponent', v=> config.gravityExponent=Number(v), v=>Number(v).toFixed(1));
  set('repulsionCoeff', v=> config.repulsionCoeff=Number(v), v=>v);

  // --- NEW SLIDERS ---
  set('gravityDistance', v=> config.gravityDistance=Number(v), v=>v);
  set('wallPosition', v => {
  const newPos = Number(v);
  const oldPos = config.wallPosition;
  if (PhysicsModule.particles && oldPos !== newPos) {
    const p = PhysicsModule.particles;
    const n = PhysicsModule.particleCount;
    const oldCx = config.width * (oldPos / 100);
    const newCx = config.width * (newPos / 100);

    for (let i = 0; i < n; i++) {
      const idx = i * 8;
      let x = p[idx];

      if (x < oldCx) {
        // Scale into new left region
        const scale = newCx / oldCx;
        p[idx] = x * scale;
      } else {
        // Scale into new right region
        const oldRightWidth = config.width - oldCx;
        const newRightWidth = config.width - newCx;
        const rel = (x - oldCx) / oldRightWidth;
        p[idx] = newCx + rel * newRightWidth;
      }
    }
  }
  config.wallPosition = newPos;
}, v => v + '%');

  set('gridSize', v=> {
      config.gridSize=Number(v);
      if(PhysicsModule.ready()) PhysicsModule.reinitGrid();
  }, v=>v+'px');

  // --- REMOVED SLIDERS ---
  // 'tunneling' (Max Speed) and 'forceSampling' are no longer wired to the UI.

  document.getElementById('collisionMode').addEventListener('change', (e)=>{
    config.useSAP = e.target.checked;
    document.getElementById('collisionModeLabel').textContent = config.useSAP?'SAP':'Grid';
  });

  document.getElementById('gravityToggle').addEventListener('change', (e)=>{
    config.gravity = e.target.checked;
    document.getElementById('gravityLabel').textContent = config.gravity?'On':'Off';
  });
  document.getElementById('frictionToggle').addEventListener('change', (e)=>{
    config.friction = e.target.checked;
    document.getElementById('frictionLabel').textContent = config.friction?'On':'Off';
  });
  document.getElementById('dragToggle').addEventListener('change', (e)=>{
    config.drag = e.target.checked;
    document.getElementById('dragLabel').textContent = config.drag?'On':'Off';
  });
  document.getElementById('pressureToggle').addEventListener('change', (e)=>{
    config.pressure = e.target.checked;
    document.getElementById('pressureLabel').textContent = config.pressure?'On':'Off';
  });

  document.getElementById('maxwellToggle').addEventListener('change', (e)=>{
    config.maxwellDemon = e.target.checked;
    document.getElementById('maxwellLabel').textContent = config.maxwellDemon ? 'On' : 'Off';
  });

  document.getElementById('uncapFpsToggle').addEventListener('change', (e) => {
    config.uncapFps = e.target.checked;
    document.getElementById('uncapFpsLabel').textContent = config.uncapFps ? 'On' : 'Off';
    if (physicsLoopId) clearInterval(physicsLoopId);
    if (adaptiveFpsIntervalId) clearInterval(adaptiveFpsIntervalId);
    if (config.uncapFps) {
      targetFps = 60;
      const adjustFps = () => {
        if (isRunning && config.uncapFps && targetFps < 240) {
            targetFps += 10;
            clearInterval(physicsLoopId);
            physicsLoopId = setInterval(physicsLoop, 1000 / targetFps);
        }
      };
      physicsLoopId = setInterval(physicsLoop, 1000 / targetFps);
      adaptiveFpsIntervalId = setInterval(adjustFps, 100);
    } else {
      targetFps = 60;
      physicsLoopId = setInterval(physicsLoop, 1000 / 60);
    }
  });

  document.getElementById('divergenceToggle').addEventListener('change', (e) => {
    config.divergenceInward = e.target.checked;
    const label = document.getElementById('divergenceLabel');
    if (config.divergenceInward) {
      label.textContent = 'Inward';
      label.style.color = '#22c55e';
    } else {
      label.textContent = 'Outward';
      label.style.color = '#3b82f6';
    }
  });

  document.getElementById('curlToggle').addEventListener('change', (e) => {
    config.curlClockwise = e.target.checked;
    const label = document.getElementById('curlLabel');
    if (config.curlClockwise) {
      label.textContent = 'Clockwise';
      label.style.color = '#22c55e';
    } else {
      label.textContent = 'Anticlockwise';
      label.style.color = '#facc15';
    }
  });

  document.getElementById('nodeToggle').addEventListener('change', (e) => {
  config.nodeMode = e.target.checked;
  const label = document.getElementById('nodeLabel');

  // Call this BEFORE updating the UI
  updateParticleSliderMax();

  label.textContent = config.nodeMode ? 'On' : 'Off';
  label.style.color = config.nodeMode ? '#22c55e' : '#7A5836';

  if (!config.nodeMode) {
    BondSystem.clear();
  }
});

  set('nodeBranches', v => {
    const val = Number(v);
    config.nodeBranches = val === 11 ? -1 : val; // 11 = "All"
  }, v => Number(v) === 11 ? 'All' : v);

  set('nodeMaxDist', v => {
    const val = Number(v);
    config.nodeMaxDist = val;
    // Update nodeMinDist slider max to match current nodeMaxDist
    const minSlider = document.getElementById('nodeMinDist');
    minSlider.max = val;
    // Ensure nodeMinDist doesn't exceed nodeMaxDist
    if (config.nodeMinDist > val) {
      config.nodeMinDist = val;
      minSlider.value = val;
      document.getElementById('nodeMinDistValue').textContent = val + 'px';
    }
  }, v => Number(v) === 2000 ? '∞' : v + 'px');

  set('nodeMinDist', v => {
    const val = Number(v);
    config.nodeMinDist = val;
    // Update nodeMaxDist slider min to match current nodeMinDist
    const maxSlider = document.getElementById('nodeMaxDist');
    maxSlider.min = val;
    // Ensure nodeMaxDist doesn't go below nodeMinDist
    if (config.nodeMaxDist < val) {
      config.nodeMaxDist = val;
      maxSlider.value = val;
      document.getElementById('nodeMaxDistValue').textContent = val + 'px';
    }
  }, v => v + 'px');

  set('bondStiffness', v => {
    // Logarithmic scale: -2 to 1 maps to 0.01 to 10
    const logVal = Number(v);
    config.bondStiffness = Math.pow(10, logVal);
  }, v => Math.pow(10, Number(v)).toFixed(2));

  document.getElementById('bondDynamicsToggle').addEventListener('change', (e) => {
    config.bondDynamics = e.target.checked;
    const label = document.getElementById('bondDynamicsLabel');
    label.textContent = config.bondDynamics ? 'On' : 'Off';
    label.style.color = config.bondDynamics ? '#22c55e' : '#7A5836';
  });

  document.getElementById('bondVisibilityToggle').addEventListener('change', (e) => {
    config.bondLinesVisible = e.target.checked;
    const label = document.getElementById('bondVisibilityLabel');
    label.textContent = config.bondLinesVisible ? 'On' : 'Off';
    label.style.color = config.bondLinesVisible ? '#22c55e' : '#7A5836';
  });

  set('bondThickness', v=> config.bondThickness=Number(v), v=>Number(v).toFixed(3)+'px');

  document.getElementById('downwardGravityToggle').addEventListener('change', (e) => {
    config.downwardGravity = e.target.checked;
    const label = document.getElementById('downwardGravityLabel');
    label.textContent = config.downwardGravity ? 'On' : 'Off';
    label.style.color = config.downwardGravity ? '#22c55e' : '#7A5836';
  });

  document.getElementById('resetBtn').addEventListener('click', ()=>{
    PhysicsModule.init(config.particleCount);
    resetGraphs();
  });
  document.getElementById('pauseBtn').addEventListener('click', (e)=>{
    isRunning = !isRunning;
    e.target.textContent = isRunning? 'Pause':'Resume';
  });
  document.getElementById('pipeBtn').addEventListener('click', (e)=>{
    config.pipeOpen = !config.pipeOpen;
    e.target.textContent = config.pipeOpen ? 'Close Pipe' : 'Open Pipe';
  });
  document.getElementById('increaseRadiusBtn').addEventListener('click', ()=>{
    if (PhysicsModule.particles) {
      const particles = PhysicsModule.particles;
      const count = PhysicsModule.particleCount;
      // Randomly select half the particles to increase radius
      const indices = Array.from({length: count}, (_, i) => i);
      // Shuffle the array
      for (let i = indices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [indices[i], indices[j]] = [indices[j], indices[i]];
      }
      // Increase radius of the first half of shuffled indices
      const halfCount = Math.floor(count / 2);
      for (let i = 0; i < halfCount; i++) {
        const particleIndex = indices[i];
        const idx = particleIndex * 8 + 7; // radius index
        particles[idx] += 1;
      }
    }
  });
  document.getElementById('decreaseRadiusBtn').addEventListener('click', ()=>{
    if (PhysicsModule.particles) {
      const particles = PhysicsModule.particles;
      const count = PhysicsModule.particleCount;
      // Randomly select half the particles to decrease radius
      const indices = Array.from({length: count}, (_, i) => i);
      // Shuffle the array
      for (let i = indices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [indices[i], indices[j]] = [indices[j], indices[i]];
      }
      // Decrease radius of the first half of shuffled indices (minimum radius of 1)
      const halfCount = Math.floor(count / 2);
      for (let i = 0; i < halfCount; i++) {
        const particleIndex = indices[i];
        const idx = particleIndex * 8 + 7; // radius index
        if (particles[idx] > 1) { // Ensure radius doesn't go below 1
          particles[idx] -= 1;
        }
      }
    }
  });
}

// Make wireUI globally accessible
window.wireUI = wireUI;
