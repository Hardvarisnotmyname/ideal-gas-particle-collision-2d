// ---------- Config & state ----------
const config = {
  particleCount: 10000,
  leftTemp: 5000,
  rightTemp: 50,
  radius: 4,
  pipeHeight: 1,
  substeps: 2,
  tunneling: 5000,
  useSAP: true,
  pipeOpen: false,
  width: 1000,
  height: 1000,
  gravity: false,
  friction: false,
  drag: false,
  pressure: false,
  maxwellDemon: false,
  demonSpeedThreshold: 10,
  uncapFps: false,
  gravityStrength: 10,
  gravityExponent: 2.0,
  repulsionCoeff: 0,
  frictionCoeff: 0.999,
  dragCoeff: 0.005,
  pressureStrength: 5,
  gridSize: 20,
  gravityDistance: 3,
  wallPosition: 50, // Percentage (0-100)
  divergenceInward: true, // true = inward, false = outward
  curlClockwise: true, // true = clockwise, false = anticlockwise
  // Node/Bond configuration
  nodeMode: false,
  bondLinesVisible: true, // toggle for bond line visibility
  bondAlpha: 0.1, // controls how strong bonds look
  bondThickness: 2.000, // thickness of bond lines in pixels
  nodeBranches: 3, // -1 = "all", otherwise 0-10
  nodeMaxDist: 200, // pixels
  nodeMinDist: 100, // pixels
  bondStiffness: 1.0, // spring constant
  bondDynamics: false, // enable/disable bond forces
  bondDamping: 0.1, // damping coefficient for bonds
  downwardGravity: false, // toggle for downward gravity force
};

// Make config globally accessible
window.config = config;
