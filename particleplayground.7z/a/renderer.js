class Renderer {
  constructor(canvas, overlayCanvas, cfg) {
    this.canvas = canvas;
    this.overlay = overlayCanvas;
    this.config = cfg;
    this.gl = null;
    this.program = null;
    this.buffers = { pos: null, col: null, rad: null };
    this.locations = { pos: null, col: null, rad: null, res: null, pr: null };
    this.tmpPos = new Float32Array(0);
    this.tmpCols = new Float32Array(0);
    this.tmpRads = new Float32Array(0);
    this.mode = 'Canvas2D';
    this.isWebGL2 = false;
    this.init();
  }
  _compileOrFallback(gl, vsSource, fsSource) {
    const vs = gl.createShader(gl.VERTEX_SHADER); gl.shaderSource(vs, vsSource); gl.compileShader(vs);
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) { return null; }
    const fs = gl.createShader(gl.FRAGMENT_SHADER); gl.shaderSource(fs, fsSource); gl.compileShader(fs);
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) { return null; }
    const prog = gl.createProgram(); gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { return null; }
    return prog;
  }
  _compileLineShaders(gl) {
    const vsSource = `#version 300 es
      in vec2 a_position;
      uniform vec2 u_resolution;
      void main() {
        vec2 pos = ((a_position / u_resolution) * 2.0 - 1.0) * vec2(1.0, -1.0);
        gl_Position = vec4(pos, 0, 1);
      }`;
    const fsSource = `#version 300 es
      precision mediump float;
      uniform vec4 u_color;
      out vec4 outColor;
      void main() {
        outColor = u_color;
      }`;
    return this._compileOrFallback(gl, vsSource, fsSource);
  }
  init() {
    this.gl = this.canvas.getContext('webgl2', { antialias: false, powerPreference: 'high-performance' })
           || this.canvas.getContext('webgl');
    const gl = this.gl;
    this.isWebGL2 = (typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext);
    const v300 = `#version 300 es
      in vec2 a_position; in vec3 a_color; in float a_radius;
      uniform vec2 u_resolution; uniform float u_pixelRatio;
      out vec3 v_color;
      void main(){
        vec2 pos = ((a_position / u_resolution) * 2.0 - 1.0) * vec2(1.0, -1.0);
        gl_Position = vec4(pos, 0, 1);
        gl_PointSize = a_radius * 1.0 * u_pixelRatio;
        v_color = a_color;
      }`;
    const f300 = `#version 300 es
      precision mediump float; in vec3 v_color; out vec4 outColor;
      void main(){ vec2 c = gl_PointCoord - vec2(0.5); float d = length(c);
        if(d>0.5) discard; float alpha = 1.0 - smoothstep(0.3,0.5,d);
        outColor = vec4(v_color, alpha);
      }`;
    this.program = this._compileOrFallback(gl, v300, f300);
    if (this.program) { this.mode = 'WebGL2'; }
    this.buffers.pos = gl.createBuffer();
    this.buffers.col = gl.createBuffer();
    this.buffers.rad = gl.createBuffer();
    this.lineProgram = this._compileLineShaders(gl);
    this.buffers.linePos = gl.createBuffer();
    this.buffers.lineCol = gl.createBuffer();
    this.lineLocations = {
      pos: gl.getAttribLocation(this.lineProgram, 'a_position'),
      color: gl.getUniformLocation(this.lineProgram, 'u_color'),
      res: gl.getUniformLocation(this.lineProgram, 'u_resolution')
    };
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.clearColor(0.05, 0.05, 0.05, 1);
    this.locations.pos = gl.getAttribLocation(this.program,'a_position');
    this.locations.col = gl.getAttribLocation(this.program,'a_color');
    this.locations.rad = gl.getAttribLocation(this.program,'a_radius');
    this.locations.res = gl.getUniformLocation(this.program,'u_resolution');
    this.locations.pr  = gl.getUniformLocation(this.program,'u_pixelRatio');
  }
  getRenderMode() { return this.gl ? this.mode : 'Canvas2D'; }
  _ensureTmp(count) {
    if (this.tmpPos.length !== count * 2) { this.tmpPos = new Float32Array(count * 2); }
    if (this.tmpCols.length !== count * 3) { this.tmpCols = new Float32Array(count * 3); }
    if (this.tmpRads.length !== count) { this.tmpRads = new Float32Array(count); }
  }
  resize() {
    const rect = this.canvas.parentElement.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const width = Math.floor(rect.width * dpr);
    const height = Math.floor(rect.height * dpr);

    this.canvas.width = width; this.canvas.height = height;
    this.canvas.style.width = rect.width + 'px'; this.canvas.style.height = rect.height + 'px';

    this.overlay.width = width; this.overlay.height = height;
    this.overlay.style.width = this.canvas.style.width; this.overlay.style.height = this.canvas.style.height;

    this.config.width = width; this.config.height = height;
    if (this.gl) this.gl.viewport(0, 0, width, height);

    this.drawWalls();
  }
  render(particles, count, bonds) {
    if (!particles || count <= 0) return;

    const gl = this.gl;
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Update and draw bonds
    if (bonds && bonds.length > 0 && this.config.bondLinesVisible) {
      this.updateBondBuffers(particles, bonds);
      if (this.bondPos && this.bondPos.length > 0) {
        // --- Enable additive blending for bonds ---
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
        gl.useProgram(this.lineProgram);
        gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers.linePos);
        gl.bufferData(gl.ARRAY_BUFFER, this.bondPos, gl.STREAM_DRAW);
        gl.enableVertexAttribArray(this.lineLocations.pos);
        gl.vertexAttribPointer(this.lineLocations.pos, 2, gl.FLOAT, false, 0, 0);
        // Set bond color with alpha from config
        gl.uniform4f(this.lineLocations.color, 0.4, 0.6, 1.0, this.config.bondAlpha);
        gl.uniform2f(this.lineLocations.res, this.config.width, this.config.height);
        gl.drawArrays(gl.TRIANGLES, 0, this.bondPos.length / 2);
        // --- Restore normal blending for particles ---
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      }
    }

    // Draw particles
    this._ensureTmp(count);
    const pos = this.tmpPos, cols = this.tmpCols, rads = this.tmpRads;
    for (let i = 0; i < count; i++) {
      const idx = i*8, i2=i*2, i3=i*3;
      pos[i2] = particles[idx]; pos[i2+1] = particles[idx+1];
      cols[i3] = particles[idx+4]; cols[i3+1] = particles[idx+5]; cols[i3+2] = particles[idx+6];
      rads[i] = particles[idx+7];
    }

    gl.useProgram(this.program);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers.pos); gl.bufferData(gl.ARRAY_BUFFER, pos, gl.STREAM_DRAW);
    gl.enableVertexAttribArray(this.locations.pos); gl.vertexAttribPointer(this.locations.pos,2,gl.FLOAT,false,0,0);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers.col); gl.bufferData(gl.ARRAY_BUFFER, cols, gl.STREAM_DRAW);
    gl.enableVertexAttribArray(this.locations.col); gl.vertexAttribPointer(this.locations.col,3,gl.FLOAT,false,0,0);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers.rad); gl.bufferData(gl.ARRAY_BUFFER, rads, gl.STREAM_DRAW);
    gl.enableVertexAttribArray(this.locations.rad); gl.vertexAttribPointer(this.locations.rad,1,gl.FLOAT,false,0,0);
    gl.uniform2f(this.locations.res, this.config.width, this.config.height);
    gl.uniform1f(this.locations.pr, window.devicePixelRatio || 1);
    gl.drawArrays(gl.POINTS, 0, count);
  }

  updateBondBuffers(particles, bonds) {
    if (!bonds || bonds.length === 0) {
      this.bondPos = new Float32Array(0);
      this.bondCol = new Float32Array(0);
      return;
    }

    const bondVertices = [];
    const thickness = this.config.bondThickness;
    for (const bond of bonds) {
      const iIdx = bond.i * 8;
      const jIdx = bond.j * 8;
      const p1x = particles[iIdx];
      const p1y = particles[iIdx + 1];
      const p2x = particles[jIdx];
      const p2y = particles[jIdx + 1];

      // Compute direction vector
      const dx = p2x - p1x;
      const dy = p2y - p1y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist === 0) continue; // Skip zero-length bonds
      const nx = dx / dist;
      const ny = dy / dist;

      // Compute perpendicular
      const px = -ny;
      const py = nx;

      // Offset by thickness/2
      const halfThickness = thickness / 2;
      const offsetX = px * halfThickness;
      const offsetY = py * halfThickness;

      // Quad vertices
      const v1x = p1x + offsetX;
      const v1y = p1y + offsetY;
      const v2x = p1x - offsetX;
      const v2y = p1y - offsetY;
      const v3x = p2x + offsetX;
      const v3y = p2y + offsetY;
      const v4x = p2x - offsetX;
      const v4y = p2y - offsetY;

      // Two triangles: v1,v2,v3 and v2,v3,v4
      bondVertices.push(v1x, v1y);
      bondVertices.push(v2x, v2y);
      bondVertices.push(v3x, v3y);
      bondVertices.push(v2x, v2y);
      bondVertices.push(v3x, v3y);
      bondVertices.push(v4x, v4y);
    }

    this.bondPos = new Float32Array(bondVertices);
    this.bondCol = new Float32Array(bondVertices.length / 2 * 3).fill(0.4, 0, 3).fill(0.6, 3, 3).fill(1.0, 6, 3); // Cyan color
  }

  drawWalls() {
    const ctx = this.overlay.getContext('2d');
    const W = this.overlay.width, H = this.overlay.height;
    const cx = W * (this.config.wallPosition / 100);
    const pipePct = this.config.pipeHeight * 0.01;
    const pipeOpen = this.config.pipeOpen;
    const openH = Math.max(2, Math.floor(H * pipePct));
    const wallThickness = Math.max(2, Math.floor(Math.min(W, H) * 0.003));

    ctx.clearRect(0, 0, W, H);

    if (this.config.pipeHeight < 100) {
      ctx.strokeStyle = '#999';
      ctx.fillStyle   = '#ff4040';
      ctx.lineWidth   = wallThickness;
      ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, H); ctx.stroke();

      if (pipeOpen && openH > 0) {
        const y0 = Math.floor((H - openH) / 2);
        const y1 = y0 + openH;
        ctx.strokeStyle = '#0f0f0f'; ctx.lineWidth = wallThickness * 1.8;
        ctx.beginPath(); ctx.moveTo(cx, y0); ctx.lineTo(cx, y1); ctx.stroke();
        ctx.fillStyle = '#ffeb3b';
        ctx.fillRect(cx - wallThickness, y0 - wallThickness, wallThickness * 2, wallThickness);
        ctx.fillRect(cx - wallThickness, y1, wallThickness * 2, wallThickness);
      }
    }
  }
}
